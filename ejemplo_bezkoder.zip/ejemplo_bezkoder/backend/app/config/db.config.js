module.exports = {
  dialect: "sqlite",
  storage: 'testdb.sqlite'
};
