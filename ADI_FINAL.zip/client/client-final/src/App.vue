<template>
  <div id="app">
    <nav>
      <router-link to="/"></router-link>
      
    </nav>
    <router-view></router-view>
  </div>
</template>

<script>
export default {

};
</script>

<style>

</style>
